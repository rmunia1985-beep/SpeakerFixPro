# Speaker Fix Pro (Android)

A simple native Android app with two functions:
- **Speaker cleaner:** 165 Hz pulsed tone for up to 45 seconds.
- **Speaker test:** low-level sweep from 220 Hz to 4 kHz for up to 25 seconds.
- Stop button and safety guidance.

## Build an APK

1. Install **Android Studio** (current stable version) on a computer.
2. Open this `SpeakerFixPro` folder in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

You can also build from a terminal with a configured Android SDK and Gradle:
`gradle assembleDebug`

## Important limitations

This app generates sound; it does not access or modify speaker hardware. It may help dislodge minor moisture or loose debris in some circumstances, but it cannot repair torn speaker cones, failed amplifiers, damaged flex cables, corrosion, or other hardware faults. Sound-based water-ejection is not guaranteed. Keep media volume low and stop if the sound is uncomfortable or distorted.

No microphone, storage, internet, or other runtime permissions are required.
