package com.speakerfixpro.app

import android.app.Activity
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Bundle
import android.os.Process
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface
import android.view.ViewGroup
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.sin

class MainActivity : Activity() {
    private val running = AtomicBoolean(false)
    @Volatile private var track: AudioTrack? = null
    private lateinit var status: TextView
    private lateinit var cleanerButton: Button
    private lateinit var testButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 24, 39)
        window.navigationBarColor = Color.rgb(16, 24, 39)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(24))
            setBackgroundColor(Color.rgb(12, 18, 31))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        scroll.addView(content)
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val title = TextView(this).apply {
            text = "🔊  Speaker Fix Pro"
            textSize = 27f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        content.addView(title, params(bottom = 10))
        content.addView(label("Clean and test your phone speaker", 15f, Color.LTGRAY), params(bottom = 22))

        val info = TextView(this).apply {
            text = "Before starting: lower your media volume to about 30–50%, disconnect headphones, and place the phone speaker-side down on a dry, soft cloth."
            textSize = 14f
            setTextColor(Color.rgb(221, 230, 245))
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setBackgroundColor(Color.rgb(28, 40, 60))
        }
        content.addView(info, params(bottom = 22))

        content.addView(label("CLEANER MODE", 13f, Color.rgb(96, 165, 250), true), params(bottom = 6))
        content.addView(label("Plays a gentle pulsing low tone that may help loosen light moisture or debris. It cannot repair hardware.", 14f, Color.LTGRAY), params(bottom = 12))
        cleanerButton = actionButton("▶  Start speaker cleaner")
        content.addView(cleanerButton, params(bottom = 20))
        cleanerButton.setOnClickListener {
            if (running.get()) stopSound() else startSound(cleaner = true)
        }

        content.addView(label("SPEAKER TEST", 13f, Color.rgb(96, 165, 250), true), params(bottom = 6))
        content.addView(label("Plays a quiet frequency sweep so you can listen for distortion, rattling, or missing sound.", 14f, Color.LTGRAY), params(bottom = 12))
        testButton = actionButton("▶  Start speaker test")
        content.addView(testButton, params(bottom = 20))
        testButton.setOnClickListener {
            if (running.get()) stopSound() else startSound(cleaner = false)
        }

        val stop = Button(this).apply {
            text = "■  Stop"
            textSize = 16f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(185, 55, 65))
        }
        content.addView(stop, LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(18) })
        stop.setOnClickListener { stopSound() }

        status = label("Status: Ready", 14f, Color.rgb(134, 239, 172))
        content.addView(status, params(bottom = 16))

        val warning = TextView(this).apply {
            text = "Safety: This app only plays sound; it cannot physically repair a damaged speaker or guarantee water removal. Keep volume low. Stop immediately if the sound is uncomfortable, the phone gets hot, or you hear harsh distortion. Do not use sound while the phone is wet or charging. If problems remain, power off the phone and seek professional service."
            textSize = 12f
            setTextColor(Color.rgb(190, 198, 211))
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(Color.rgb(28, 40, 60))
        }
        content.addView(warning, params(bottom = 12))
        setContentView(page)
    }

    private fun startSound(cleaner: Boolean) {
        if (!running.compareAndSet(false, true)) return
        cleanerButton.isEnabled = false
        testButton.isEnabled = false
        status.text = if (cleaner) "Status: Cleaner running…" else "Status: Speaker test running…"
        thread(name = "SpeakerAudio") {
            Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
            val sampleRate = 44100
            val min = AudioTrack.getMinBufferSize(
                sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val bufferSize = maxOf(min, 4096)
            val audio = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(sampleRate)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            track = audio
            try {
                audio.play()
                val samples = ShortArray(2048)
                var phase = 0.0
                var elapsed = 0
                val totalSamples = sampleRate * if (cleaner) 45 else 25
                while (running.get() && elapsed < totalSamples) {
                    for (i in samples.indices) {
                        val t = elapsed.toDouble() / sampleRate
                        val frequency = if (cleaner) {
                            165.0
                        } else {
                            220.0 + (t / 25.0) * 3780.0
                        }
                        val pulse = if (cleaner) {
                            if ((t % 2.0) < 1.25) 1.0 else 0.0
                        } else 1.0
                        // Conservative amplitude; device media volume remains under user control.
                        val value = sin(phase) * 0.18 * pulse
                        samples[i] = (value * Short.MAX_VALUE).toInt().toShort()
                        phase += 2.0 * PI * frequency / sampleRate
                        if (phase > 2.0 * PI) phase -= 2.0 * PI
                        elapsed++
                    }
                    audio.write(samples, 0, samples.size)
                }
            } catch (_: Exception) {
            } finally {
                try { audio.pause(); audio.flush(); audio.stop() } catch (_: Exception) {}
                audio.release()
                track = null
                running.set(false)
                runOnUiThread {
                    cleanerButton.isEnabled = true
                    testButton.isEnabled = true
                    status.text = "Status: Ready"
                }
            }
        }
    }

    private fun stopSound() {
        running.set(false)
        try { track?.pause(); track?.flush() } catch (_: Exception) {}
        status.text = "Status: Stopping…"
    }

    private fun label(textValue: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            text = textValue
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun actionButton(caption: String) = Button(this).apply {
        text = caption
        textSize = 16f
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(37, 99, 235))
        isAllCaps = false
    }

    private fun params(bottom: Int = 0) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = dp(bottom) }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        stopSound()
        super.onDestroy()
    }
}
